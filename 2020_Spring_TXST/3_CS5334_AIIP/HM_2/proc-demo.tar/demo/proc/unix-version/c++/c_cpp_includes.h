/*
 FILE DESCRIPTION: This file contains C/C++ header files that should 
 be commonly included
 */

//#include <cstdlib.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include <iostream>
#include <fstream>
#include <ostream>
#include <sstream>
#include <iosfwd>
#include <iomanip>

//#include <iomanip.h>

using namespace std;

//#include <iostream>
//#include <ostream>
//#include <cstdio>
