#include <QApplication>
#include <QKeyEvent>
#include "KeyPress.h"
#include <QDebug>
  
KeyPress::KeyPress(QWidget *parent) :
    QWidget(parent)
{
	int CapsLock_ON = 0;	  // global variable
	int lowerCaseCount = 1;	

    qDebug()<<"Key board game start~~~~~~!!!!";
}

void KeyPress::keyPressEvent(QKeyEvent *event)
{
      
     if (event->type() == QEvent::KeyPress){ 
 
	 QKeyEvent *keyEvent = static_cast<QKeyEvent*>(event); 

              if(keyEvent->key() == 16777252){   // Check if CapsLock is ON
		    CapsLock_ON = !CapsLock_ON;
                    qDebug()<<"flip!!!";
                    qDebug()<<CapsLock_ON;
          
	       }

	       if(CapsLock_ON==false) {
		qDebug()<<"SKIP!!  -->  CapsLock is ON!!!!";  // Skip the counter if capslock is ON
		 	
		} else {
 
		       int keyInt = keyEvent->key(); 
		       Qt::Key key = static_cast<Qt::Key>(keyInt); 
	   
		       QString keyText = keyEvent->text(); 
 
		       qDebug()<<keyInt;
		        
                       if(keyInt>=65 && keyInt <=90){   //  only consider letter from A-Z (they are case insensitive!!!)
			       
                               qDebug()<<"lower case count: ";    
			       qDebug()<<lowerCaseCount;     
			       lowerCaseCount++;
		         
			       qDebug() << "New KeySequence:" << QKeySequence(keyInt).toString(QKeySequence::NativeText); 
			}
	     }     
	} 
 
}
 






 
