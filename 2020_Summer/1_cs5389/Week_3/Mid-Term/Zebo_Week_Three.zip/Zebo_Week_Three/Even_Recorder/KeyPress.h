#include <QWidget>
#include <QtGui>

class KeyPress : public QWidget
{
    Q_OBJECT

public:
    int lowerCaseCount;
    int CapsLock_ON;
    KeyPress(QWidget *parent = 0);

public:
    void keyPressEvent(QKeyEvent *event);
  
private:
    QLabel *myLabelText;
};
