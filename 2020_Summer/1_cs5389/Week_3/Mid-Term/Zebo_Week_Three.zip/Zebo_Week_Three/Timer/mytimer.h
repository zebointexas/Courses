#ifndef MYTIMER_H
#define MYTIMER_H
#include <QWidget>
#include <QtGui>
#include <QTimer>

class MidTermTimer : public QObject
{
        Q_OBJECT

	public:

	    MidTermTimer();
	    QTimer *timer;
	public slots:
	    void fire();
            
  
};
 
class KeyPress : public QWidget
{
    Q_OBJECT

public:
    KeyPress(QWidget *parent = 0);

protected:
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);

private:
    QLabel *myLabelText;
};


#endif // MYTIMER_H
