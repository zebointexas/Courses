#include "mytimer.h"
#include <QDebug>
#include <string>
#include <iostream>
#include <QApplication>
#include <QKeyEvent>
 
 
using namespace std;

int count = 1;

MidTermTimer::MidTermTimer()
 
    timer = new QTimer(this);
 
    int count = 1; 
 
    //Signal and Slot
    connect(timer, SIGNAL(timeout()), this, SLOT(fire()));
	 
    // Recurring event every 2 seconds.
    timer->start(2000);  
    // Call back function from timer object. Here the call back function is "start()"
}

void MidTermTimer::fire()
{
    qDebug() << "Rocket launched times: ";
    qDebug() << count++;   
}
