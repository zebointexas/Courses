#include <QCoreApplication>
#include "mytimer.h"
#include <iostream>
using namespace std;



int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
  
    MidTermTimer timer;
 
    return a.exec();
}
